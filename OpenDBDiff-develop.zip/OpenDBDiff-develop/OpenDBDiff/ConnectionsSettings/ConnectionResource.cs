namespace OpenDBDiff.ConnectionsSettings
{
    public class ConnectionResource
    {
        public string ConnectionStringDestination { get; set; }

        public string ConnectionStringSource { get; set; }

        public string Type { get; set; }

        public string Name { get; set; }
    }
}
