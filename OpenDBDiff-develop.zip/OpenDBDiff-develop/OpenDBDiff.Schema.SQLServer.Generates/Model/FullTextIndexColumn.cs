﻿namespace OpenDBDiff.Schema.SQLServer.Generates.Model
{
    public class FullTextIndexColumn
    {
        public string Language { get; set; }

        public string ColumnName { get; set; }
    }
}
