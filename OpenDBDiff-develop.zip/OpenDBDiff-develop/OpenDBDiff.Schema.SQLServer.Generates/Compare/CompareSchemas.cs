namespace OpenDBDiff.Schema.SQLServer.Generates.Compare
{
    internal class CompareSchemas : CompareBase<Model.Schema>
    {

    }
}
